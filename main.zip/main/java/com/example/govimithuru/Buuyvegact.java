package com.example.govimithuru;

public class Buuyvegact {

    String vegetable,image;

    public Buuyvegact() {

    }

    public Buuyvegact(String vegetable, String image) {
        this.vegetable = vegetable;
        this.image = image;
    }

    public String getVegetable() {
        return vegetable;
    }

    public void setVegetable(String vegetable) {
        this.vegetable = vegetable;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
